#include "Tema1.h"
#include "Object2D.h"
#include <Core/Engine.h>

#include <vector>
#include <iostream>

#include "Transform2D.h"
#include "Object2D.h"

using namespace std;

#define PI 3.14159265


Tema1::Tema1()
{
}

Tema1::~Tema1()
{
}

void Tema1::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	mouse_click = false;
	lives = 3;
	ball_cos = 0;
	ball_sin = 1;
	game_begun = false;

	
	// initializari pentru caramizi
	for (int i = 0; i < BRICKS; i++) {
		
		hit[i] = 1;
		modelMatricesBricks[i] = glm::mat3(1);
		scale[i] = 1;

		// punem power-ups random
		int k = rand() % 100;
		if (k % 3 == 0) {
			power_type[i] = i % 6;
			modelMatricesPowers[i] = glm::mat3(1);
			translateY[i] = 0;
			angularStep[i] = 0;
		}
	}
	
	// borders
	Mesh* border_left;
	Mesh* border_right;
	Mesh*  border_top;
	Mesh*  border_down;
	int i;

	glm::vec3 corner = glm::vec3(0, 40, 0);
	border_left = Object2D::CreateRectangle("border_left", corner, border_weight, resolution.y - 40, glm::vec3(0.4, 0, 0.6), true);
	AddMeshToList(border_left);

	corner = glm::vec3(resolution.x - border_weight, 40, 0);
	border_right = Object2D::CreateRectangle("border_right", corner, border_weight, resolution.y - 40, glm::vec3(0.4, 0, 0.6), true);
	AddMeshToList(border_right);

	corner = glm::vec3(0, resolution.y - border_weight, 0);
	border_top = Object2D::CreateRectangle("border_top", corner, resolution.x, border_weight, glm::vec3(0.4, 0, 0.6), true);
	AddMeshToList(border_top);

	corner = glm::vec3(0, 0, 0);
	border_down = Object2D::CreateRectangle("border_down", corner, resolution.x, border_weight, glm::vec3(0.4, 0, 0.5), true);
	AddMeshToList(border_down);
	
	// bricks
	Mesh *bricks[BRICKS];
	Mesh *powers[BRICKS];
	int x, y;
	int k = 0;

	int hard_blocks = level; // nr de randuri cu caramizi dure
	int bricks_per_row = rand() % 12 + 4;
	int row_number = 0;
	int rand1 = rand() % 3 + 2, rand2 = rand() % 3 + 2;

	float step; // daca pe urmatotul rand asezam mai multe(step = -1) sau mai putine(step = 1) caramizi
	if (bricks_per_row < 8)
		step = 1;
	else
		step = -1;
	float start = resolution.x / 2 - (bricks_per_row * brick_length + (bricks_per_row - 1) * 10) / 2; // coord x a primei caramizi

	for (int n = 0, x = start, y = resolution.y - 120; n < BRICKS; n++, x += brick_length + 10) {
		
		if (n + bricks_per_row <= BRICKS) {
			if (k == bricks_per_row) {
				row_number++;
				if ((bricks_per_row == 8 && step == -1)||( bricks_per_row == 13 && step == 1))
					step *= -1;
				bricks_per_row += step;
				k = 0;
				x = resolution.x / 2 - (bricks_per_row * brick_length + (bricks_per_row - 1) * 10) / 2;
				y -= (brick_height + 10);
				if (hard_blocks > 0 && row_number % rand1 == 0)
					hard_blocks--;
			}
		}
		else {
			if (k == bricks_per_row) {
				row_number++;
				bricks_per_row += step;
				k = 0;
				x = resolution.x / 2 - ((BRICKS - n)*brick_length + (BRICKS - n - 1) * 10) / 2;
				y -= (brick_height + 10);
				if (hard_blocks > 0 && row_number % rand1 == 0)
					hard_blocks--;
			}
		}
		k++;

		corner = glm::vec3(x, y, 0);
		string name = "brick" + std::to_string(n);

		if (hard_blocks > 0 && (row_number % rand1 == 0)) {
			bricks[n] = Object2D::CreateRectangle(name, corner, brick_length, brick_height, glm::vec3(0.18, 0.18, 0.18), true);
			hit[n] = 3;
		}
		else {
			bricks[n] = Object2D::CreateRectangle(name, corner, brick_length, brick_height, glm::vec3(0.2 + (float)n / 150, (float)(n % 7) / 10, (float)x / 500), true);
		}
		AddMeshToList(bricks[n]);

		//putere
		name = "power" + std::to_string(n);
		corner = glm::vec3(x + (brick_length - power_length) / 2, y + (brick_height - power_length) / 2, 0);
		power_center[n] = y + brick_height / 2;
		glm::vec3 power_color;
		switch (power_type[n]) {
		case 1:
			power_color = glm::vec3(0, 0.5, 1); // perete
			break;
		case 2:
			power_color = glm::vec3(1, 0.5, 1); // bila mare
			break;
		case 3:
			power_color = glm::vec3(0, 1, 0); // lipici
			break;
		case 4:
			power_color = glm::vec3(0.5, 0, 0.9); // bila mai puternica
			break;
		case 5:
			power_color = glm::vec3(0, 1, 1);
			break;
		}
		powers[n] = Object2D::CreateSquare(name, corner, power_length, power_color, true);
		AddMeshToList(powers[n]);	
	}

	//puteri
	for (int p = 0; p < POWERS; p++)
		power_activated[p] = 0;

	// what to do with VERTEX
	vector<VertexFormat> v = meshes["brick0"]->vertices;
	glm::vec3 pos = v[0].position;
		
	// pad
	Mesh *pad;
	pad_x = resolution.x/2 - pad_lenght/2;
	pad_y = border_weight;
	
	corner = glm::vec3(0, 0, 0);
	pad = Object2D::CreateRectangle("pad", corner, pad_lenght, pad_height , glm::vec3(255, 255, 255), true);
	AddMeshToList(pad);

	//ball
	ball_y = pad_y + pad_height + ball_radius;
	ball_x = pad_x + pad_lenght / 2;
	ball_radius = small_ball_radius;
	//small_ ball
	Mesh* ball = new Mesh("small_ball");
	ball = Object2D::CreateCyrcle("ball", ball_radius - 4, 0, 0, 100,glm::vec3(0,255,0), true);
	AddMeshToList(ball);
	//big_ball
	Mesh* big_ball = new Mesh("big_ball");
	big_ball = Object2D::CreateCyrcle("big_ball", big_ball_radius - 6, 0, 0, 100, glm::vec3(0, 255, 0), true);
	AddMeshToList(big_ball);

	// lives
	Mesh* live1 = new Mesh("live1");
	Mesh* live2 = new Mesh("live2");
	Mesh* live3 = new Mesh("live3");
	live1 = Object2D::CreateCyrcle("live1", 8, 10, 20, 30, glm::vec3(0, 0.7, 0.5), true);
	live2 = Object2D::CreateCyrcle("live2", 8, 30, 20, 30, glm::vec3(0, 0.7, 0.5), true);
	live3 = Object2D::CreateCyrcle("live3", 8, 50, 20, 30, glm::vec3(0, 0.7, 0.5), true);
	AddMeshToList(live1);
	AddMeshToList(live2);
	AddMeshToList(live3);

	// laser weapond
	corner = glm::vec3(0, 0, 0);
	Mesh* laser_weapond = new Mesh("laser_weapond");
	laser_weapond = Object2D::CreateRectangle("laser_weapond", corner, 3, 700, glm::vec3(0, 1, 1), true);
	AddMeshToList(laser_weapond);
}

void Tema1::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema1::Update(float deltaTimeSeconds)
{
	glm::ivec2 resolution = window->GetResolution();
	
	// dezactiveaza bonusurile expirate
	for (int i = 0; i < POWERS; i++) {
		
		if (time_power[i] >= 30) {
			power_activated[i] = false;
			if(i == 2)
				ball_radius = small_ball_radius;
		}
		else {
			time_power[i] += deltaTimeSeconds;
		}
	}

	// render borders
	modelMatrix = glm::mat3(1);
	RenderMesh2D(meshes["square"], shaders["VertexColor"], modelMatrix);
	RenderMesh2D(meshes["border_left"], shaders["VertexColor"], modelMatrix);
	RenderMesh2D(meshes["border_right"], shaders["VertexColor"], modelMatrix);
	RenderMesh2D(meshes["border_top"], shaders["VertexColor"], modelMatrix);
	// bonus 1 => apare un perete jos
	if (power_activated[1] == true)
		RenderMesh2D(meshes["border_down"], shaders["VertexColor"], modelMatrix);

	// render pad
	modelMatrix = glm::mat3(1);
	modelMatrix *= Transform2D::Translate(pad_x, pad_y);
	RenderMesh2D(meshes["pad"], shaders["VertexColor"], modelMatrix);
	
	// render bricks
	int allowed_hits = 1;
	bool game_win = true;
	
	for (int n = BRICKS - 1; n >= 0; n--) {
		if (hit[n] > 0)
			game_win = false;
		string name = "brick" + std::to_string(n);
		vector<VertexFormat> v = meshes[name]->vertices;
		glm::vec3 p0 = v[0].position; // colt stanga jos
		glm::vec3 p2 = v[2].position; // colt stanga sus

		// randare putere arma laser => la apasarea tastei "space"
		if ((power_activated[5] == true) && (space_key_pressed == true)) {
			modelMatrixLaser = glm::mat3(1);
			modelMatrixLaser *= Transform2D::Translate(pad_x + pad_lenght / 2, pad_y + pad_height);
			if ((p0.x < pad_x + pad_lenght / 2) && (p2.x > pad_x + pad_lenght / 2) && (hit[n] > 0)) {
				hit[n]--;
				allowed_hits--;
				space_key_pressed = false;
			}
			else {
			}
			RenderMesh2D(meshes["laser_weapond"], shaders["VertexColor"], modelMatrixLaser);
		}

		// daca caramida nu era lovita sau nu am lovit deja o alta caramida => verific daca o loveste mingea
		if (hit[n] > 0 && allowed_hits > 0) {
			
			//lovire caramida din lateral
			if (ball_y >= p0.y && ball_y <= p2.y) {
				if (
					((ball_x + ball_radius >= p0.x) && (ball_x + ball_radius <= p0.x + brick_length / 2)) ||
					((ball_x - ball_radius >= p0.x + brick_length) && (ball_x - ball_radius <= p2.x))
					) {
					// lovita din 1.stanga 2.dreapta
					hit[n]--;
					allowed_hits--;
					if (power_activated[4] != true)
						ball_cos *= (-1);
				}
			}

			//lovire caramida de sus sau jos
			if (ball_x >= p0.x && ball_x <= p2.x) {
				if ( //sus, jos
					((ball_y - ball_radius <= p2.y) && (ball_y - ball_radius >= p2.y - brick_height / 2)) ||
					((ball_y + ball_radius <= p2.y - brick_height / 2) && (ball_y + ball_radius >= p2.y))
					) {
					if (power_activated[4] != true)
						ball_sin *= (-1);
					hit[n]--;
					allowed_hits--;
				}
			}

			// lovitura caramida in colturi
			float d = ball_radius / 1.41421;
			if ( // stanga-jos, stanga-sus, dreapta-sus, dreapta-jos
				((ball_x + d >= p0.x) && (ball_y + d >= p0.y) && (ball_x <= p0.x + brick_length / 2) && (ball_y <= p0.y + brick_height / 2)) ||
				((ball_x + d >= p0.x) && (ball_y - d <= p2.y) && (ball_x <= p0.x + brick_length / 2) && (ball_y >= p0.y + brick_height / 2)) ||
				((ball_x - d <= p2.x) && (ball_y - d <= p0.y) && (ball_x >= p0.x + brick_length / 2) && (ball_y >= p0.y + brick_height / 2)) ||
				((ball_x - d <= p2.x) && (ball_y + d >= p0.y) && (ball_x >= p0.x + brick_length / 2) && (ball_y <= p0.y + brick_height / 2))
				) {
				hit[n]--;
				allowed_hits--;

				if (power_activated[4] != true) {
					ball_sin *= (-1);
					ball_cos *= (-1);
				}
			}
		}

		// lovita tura asta, sau mai devreme si nu a disparut inca => se afiseaza micsorata
		if (hit[n] == 0 && scale[n] > 0) {
			
			modelMatricesBricks[n] *= Transform2D::Translate((p0.x + brick_length / 2), (p0.y + brick_height / 2));
			modelMatricesBricks[n] *= Transform2D::Scale(scale[n], scale[n]);
			modelMatricesBricks[n] *= Transform2D::Translate(-(p0.x + brick_length/2), -(p0.y + brick_height/2));
			RenderMesh2D(meshes[name], shaders["VertexColor"], modelMatricesBricks[n]);
			scale[n] -= deltaTimeSeconds;
		}
		
		// caramida nu a fost lovita => dimensiune normala
		if (hit[n] > 0) {
			RenderMesh2D(meshes[name], shaders["VertexColor"], modelMatricesBricks[n]);
		}

		// lovita
		else {
			// caramida lovita => verific daca a avut bonusuri si ce se intampla cu ele
			if (power_type[n] > 0) {
				
				if (translateY[n] < (power_center[n] - border_weight - pad_height)) {
					// daca power-up nu a ajuns jos => continua sa cada
					angularStep[n] += 5;
					translateY[n] += 1;
					string power_name = "power" + std::to_string(n);
					modelMatricesPowers[n] = glm::mat3(1);
					modelMatricesPowers[n] *= Transform2D::Translate(0, -translateY[n]);
					modelMatricesPowers[n] *= Transform2D::Translate((p0.x + brick_length / 2), power_center[n]);
					modelMatricesPowers[n] *= Transform2D::Rotate(angularStep[n]);
					modelMatricesPowers[n] *= Transform2D::Translate(-(p0.x + brick_length / 2), -power_center[n]);

					RenderMesh2D(meshes[power_name], shaders["VertexColor"], modelMatricesPowers[n]);
				}
				else {
					// power-up este la inaltimea padului => verifica daca il pride pad-ul
					if (((p0.x + brick_length / 2) > pad_x) 
							&& ((p0.x + brick_length / 2) < (pad_x + pad_lenght))
							&& (translateY[n] <= (p0.y + brick_height/2 - border_weight))
							) {

						power_activated[power_type[n]] = true;
						time_power[power_type[n]] = 0;
					}
						else
							power_type[n] = 0;

				}
			}
		}
	}

	if (game_win == true) {
		level = (level + 1)%LEVELS;
		Tema1::Init();
	}

	// render ball
	//coliziune minge pad
	if ((ball_y - ball_radius < pad_y + pad_height) && (ball_x > pad_x && ball_x < pad_x + pad_lenght)) {
		if (power_activated[3] == true) {
			//pad lipicios
			mouse_click = false;
			ball_delay = ball_x - pad_x;
			ball_cos = 0;
			ball_sin = 1;
		}
		else {
			// se reflecta de pe pad
			float cos = (ball_x - (pad_x + pad_lenght / 2)) / (pad_lenght / 2);
			float angle = acosf(cos);
			ball_cos = cosf(angle);
			ball_sin = sinf(angle);
		}
	}

	//coliziune minge jos 
	if ((ball_y - ball_radius < pad_y + pad_height) && !(ball_x > pad_x && ball_x < pad_x + pad_lenght)) {
		if (power_activated[1] == true) {
			// apare un perete care salveaza o minge sau dispare dupa 30 s
			if (ball_y - ball_radius <= border_weight){
				ball_sin *= (-1);
				ball_y += 2;
				time_power[1] = 29;
			}
		}
		else {
			// platforma nu a salvat mingea
			mouse_click = false;
			if(game_begun == true)
				lives--;
			if (lives == 0) {
				//game_over => incepe iar
				lives = 3;
				Tema1::Init();
			}
		}
		
	}

	//coliziune minge pereti
	//stanga
	if (ball_x - ball_radius <= border_weight)
		ball_cos *= (-1);
	//dreapta
	if (ball_x + ball_radius >= resolution.x - border_weight)
		ball_cos *= (-1);
	//sus
	if (ball_y + ball_radius >= resolution.y - border_weight - 1)
		ball_sin *= (-1);

	modelMatrix = glm::mat3(1);
	if (mouse_click == true) {
		ball_y += ball_sin * deltaTimeSeconds * ball_speed;
		ball_x += ball_cos * deltaTimeSeconds * ball_speed;
		modelMatrix *= Transform2D::Translate(ball_x, ball_y);
	}
	else { // mouse click este fals => inca nu a pornit mingea de pe platforma
		if (power_activated[3] == true) {
			// a fost platforma lipicioasa => s-a lipit la pozitia in care a cazut
			ball_y = pad_y + pad_height + ball_radius;
			ball_x = pad_x + ball_delay;
			ball_sin = 1;
			ball_cos = 0;
			modelMatrix *= Transform2D::Translate(ball_x, ball_y);
		}
		else { // s-a inceput jocul sau s-a pierdut o viata => mingea e pe mijlocul platformei
			ball_y = pad_y + pad_height + ball_radius;
			ball_x = pad_x + pad_lenght / 2;
			modelMatrix *= Transform2D::Translate(ball_x, ball_y);
		}
	}

	//putere2 -> bila mai mare
	if (power_activated[2] == true) {
		RenderMesh2D(meshes["big_ball"], shaders["VertexColor"], modelMatrix);
		ball_radius = big_ball_radius;		
	}
	else
		RenderMesh2D(meshes["ball"], shaders["VertexColor"], modelMatrix);

	// render lives
	modelMatrix = glm::mat3(1);
	if (lives >= 1)
		RenderMesh2D(meshes["live1"], shaders["VertexColor"], modelMatrix);
	if (lives >= 2)
		RenderMesh2D(meshes["live2"], shaders["VertexColor"], modelMatrix);
	if (lives >= 3)
		RenderMesh2D(meshes["live3"], shaders["VertexColor"], modelMatrix);
}

void Tema1::FrameEnd()
{

}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{
	glm::ivec2 resolution = window->GetResolution();
}

void Tema1::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_SPACE) {
		space_key_pressed = true;
	}
}

void Tema1::OnKeyRelease(int key, int mods)
{
	// add key release event
	if (key == GLFW_KEY_SPACE) {
		space_key_pressed = false;
	}
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
	glm::ivec2 resolution = window->GetResolution();
	if ((deltaX > 0 && ((pad_x + deltaX + pad_lenght + 5) < resolution.x - border_weight)) || (mouseX > resolution.x - border_weight)) {
		pad_x += pad_speed*deltaX;
	}
	if((deltaX < 0 && ((pad_x - deltaX) > border_weight)) || mouseX < border_weight){
		pad_x += pad_speed*deltaX;
	}
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	if (mouse_click == false)
		mouse_click = true;
	if (game_begun == false)
		game_begun = true;
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema1::OnWindowResize(int width, int height)
{
}
