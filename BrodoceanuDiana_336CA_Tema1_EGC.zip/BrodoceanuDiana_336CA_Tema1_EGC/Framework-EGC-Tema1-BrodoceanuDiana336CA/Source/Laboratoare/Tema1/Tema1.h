#pragma once

#include <Component/SimpleScene.h>
#include <string>
#include <Core/Engine.h>
#include <cstdlib>

constexpr auto BRICKS = 96;
constexpr auto POWERS = 6;
constexpr auto LEVELS = 10;


struct Brick {
	float x;
	float y;
	float width;
	float height;
};

class Tema1 : public SimpleScene
{
	public:
		Tema1();
		~Tema1();

		void Init() override;

	private:
		void FrameStart() override;
		void Update(float deltaTimeSeconds) override;
		void FrameEnd() override;

		void OnInputUpdate(float deltaTime, int mods) override;
		void OnKeyPress(int key, int mods) override;
		void OnKeyRelease(int key, int mods) override;
		void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
		void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
		void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
		void OnWindowResize(int width, int height) override;

	protected:
		glm::mat3 modelMatrix;
		//float translateY, translateY;
		float scaleX, scaleY;
		//float angularStep;
		bool scaleFlag = false,translateFlag,rotateFlag;

	public:
		//borders
		float border_weight = 32;

		//bricks
		float brick_length = 60;
		float brick_height = 30;
		int hit[BRICKS];
		glm::mat3 modelMatricesBricks[BRICKS];
		float scale[BRICKS];

		// puteri 
		float power_length = 20;
		int power_type[BRICKS]; // 0->fara, 1->bonus1, 2->bonus2, 3->bonus3
		glm::mat3 modelMatricesPowers[BRICKS];
		float power_center[BRICKS];
		float angularStep[BRICKS];
		float translateY[BRICKS];

		float scale_weapond = 1;
		float y_weapond;
		bool space_key_pressed = false;
		glm::mat3 modelMatrixLaser;
		
		float time_power[POWERS];
		bool power_activated[POWERS];

		//pad
		float pad_height = 10;
		float pad_lenght = 180;
		float pad_x, pad_y;
		float pad_speed = 1;


		//ball
		float ball_x;
		float ball_y;
		float ball_speed = 200;
		float ball_cos = 0;
		float ball_sin = 1;
		float small_ball_radius = 15;
		float ball_radius = 10;
		float big_ball_radius = 37;

		float ball_delay;

		//click => zboara bila de pe pad
		bool mouse_click = false;

		//vieti
		int lives = 3;

		// nivel
		int level = 1;

		bool game_begun = false;
		
};
